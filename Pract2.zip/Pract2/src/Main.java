public class Main {
    public static void main(String[] args) {
        Person person = new Person("Joshua",30);
        person.displayInfo();
    }
}
