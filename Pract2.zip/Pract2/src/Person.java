public class Person {
    public Person(String joshua, int i) {
    }
}
